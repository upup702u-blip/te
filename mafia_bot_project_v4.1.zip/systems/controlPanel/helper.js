/**
 * Legacy helper module kept for reference.
 * Functionality has been merged into index.js in v4.1.
 * This file exposes helper utilities if you wish to require them.
 */
const fs = require('fs');
const path = require('path');
const cfgPath = path.join(__dirname,'..','..','config.json');
function readConfig(){ return JSON.parse(fs.readFileSync(cfgPath,'utf8')); }
module.exports = { readConfig };
