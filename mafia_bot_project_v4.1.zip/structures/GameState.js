class GameState {
  constructor(){ this.reset(); }
  reset() {
    this.players = [];
    this.allPlayers = [];
    this.playerRoles = new Map();
    this.mafias = [];
    this.doctor = null;
    this.detector = null;
    this.bodyguard = null;
    this.witch = null;
    this.oldWoman = null;
    this.harlot = null;
    this.hunter = null;
    this.mayor = null;
    this.president = null;
    this.jester = null;
    this.killedPlayer = null;
    this.protectedPlayer = null;
    this.shieldedPlayer = null;
    this.currentRound = 0;
    this.gameActive = false;
    this.votes = new Map();
    this.votesOrder = [];
    this.timeouts = [];
    this.mafiaActions = new Map();
    this.witchSaveAvailable = true;
    this.witchKillAvailable = true;
  }
  pushTimeout(t){ this.timeouts.push(t); }
  clearAllTimeouts(){ this.timeouts.forEach(t=>clearTimeout(t)); this.timeouts = []; }
}
module.exports = GameState;
